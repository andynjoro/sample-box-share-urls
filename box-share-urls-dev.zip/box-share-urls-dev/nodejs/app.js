/* Express Setup */
const express = require('express');
const app = express();

app.listen(3000);

/* Box SDK Setup */
const boxSDK = require('box-node-sdk');
const fs = require('fs');
const configJSON = JSON.parse(fs.readFileSync('config/config.json'));
const sdk = boxSDK.getPreconfiguredInstance(configJSON);

app.get('/account', function (req, res) {
    const adminClient = sdk.getAppAuthClient('enterprise', sdk.enterpriseId);

    let email = req.query.email;

    // Get users
    adminClient.enterprise.getUsers({
        filter_term: email
        })
        .then(users => {    
            res.json(users.entries);
        });
});

app.get('/search', function (req, res) {
    let box_account_id = req.query.box_account_id;

    const appUserClient = sdk.getAppAuthClient('user', box_account_id);
    
    const searchTerm = req.query.folder_query;
    const type = 'folder';
    const scope = 'user_content';
    const limit = 1000;
    const offset = 0;

    // Initiate search
    appUserClient.search.query(
        searchTerm, {
            scope: scope,
            type: type,
            limit: limit,
            offset: offset
        },
        search_callback
    );

    function search_callback(error, results) {
        res.json(results.entries);
    }
});

function autoPage(iterator) {
    let collection = [];
    let moveToNextItem = () => {
        return iterator.next()
            .then((item) => {
                if (item.value) {
                    collection.push(item.value);
                }
                if (item.done !== true) {
                    return moveToNextItem();
                } else {
                    return collection;
                }
            })
    }
    return moveToNextItem();
}

app.get('/user-tree', function (req, res) {
    let box_account_id = req.query.box_account_id;
    let folder_id = req.query.folder_id;

    const appUserClient = sdk.getAppAuthClient('user', box_account_id);

    appUserClient._useIterators = true;
    
    const limit = 1000;

    let user_folders = [];
    let user_folder = {};
    
    user_folder["id"] = folder_id;

    if (folder_id == "0") {
        user_folder["state"] = {opened: true};
    }

    

    // Get folder items
    appUserClient.folders.get(folder_id, null)
        .then((folderInfo) => {
            user_folder["text"] = folderInfo.name;

            return appUserClient.folders.getItems(folder_id, { limit: 1000 });
        })
        .then((folderItemsIterator) => {
            return autoPage(folderItemsIterator);
        })
        .then((folderItems) => {
            let folders = folderItems.filter((item) => {
                return item.type === "folder";
            });

            let user_folder_children = [];

            folders.forEach((folder) => {
                let user_folder_child = {id : Number(folder.id),
                                        text : folder.name,
                                        children : true};
                                   
               user_folder_children.push(user_folder_child);
            });

            user_folder["children"] = user_folder_children;

            user_folders.push(user_folder);
        }).then(() => {
            res.json(user_folders);
        });
});

app.get('/get-share-urls', function (req, res) {
    let box_account_id = req.query.box_account_id;
    let folder_id = req.query.folder_id;

    const appUserClient = sdk.getAppAuthClient('user', box_account_id);

    appUserClient._useIterators = true;
    
    const limit = 1000;

    let share_urls = [];

    // Get folder items
    appUserClient.folders.getItems(folder_id, {limit: limit})
        .then((folderItemsIterator) => {
            return autoPage(folderItemsIterator);
        })
        .then((folderItems) => {
            let files = folderItems.filter((item) => {
                return item.type === "file";
            });
            
            let updatePromises = [];

            files.forEach((file) => {
                updatePromises.push(appUserClient.files.update(file.id, {shared_link: {access: "open"}})
                    .then(result_file => {
                        let share_url = {file_name: result_file.name, file_share_url: result_file.shared_link.url};
                        share_urls.push(share_url);
                    }));
            });

            return Promise.all(updatePromises);

        }).then(() => {
            res.json(share_urls);
        });
});

