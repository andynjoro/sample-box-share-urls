<?php
    $box_account_id = $_GET["box_account_id"];
    $folder_id = $_GET["id"];

    if ($folder_id == "#") {
        $folder_id = "0";
    }

    $url = "http://localhost:3000/user-tree?box_account_id=" . $box_account_id . "&folder_id=" . $folder_id;

    $results = file_get_contents($url);

    header('Content-Type: application/json');

    echo $results;