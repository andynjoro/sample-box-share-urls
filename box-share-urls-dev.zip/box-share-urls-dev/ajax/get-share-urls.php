<?php
    $box_account_id = $_GET["box_account_id"];
    $folder_id = $_GET["folder_id"];

    $url = "http://localhost:3000/get-share-urls?box_account_id=" . $box_account_id . "&folder_id=" . $folder_id;

    $results = file_get_contents($url);

    echo $results;