function display_modal_overlay() {
	var width = $(window).width();
	var height = $(document).height();
	
	$("#modal_overlay").css("width", width);
	$("#modal_overlay").css("height", height);
	$("#modal_overlay").css("opacity", 0.9);
	$('#modal_overlay').show();
}

function hide_modal_overlay() {
	$("#modal_overlay").hide();
}

function display_modal_ajax_loader() {	
	var width = $(window).width();
	var height = $(window).height();
	var lightbox_width = 300;
	var lightbox_height = 30;
	var left = (width / 2) - (lightbox_width / 2);
	var top = (height / 2) - (lightbox_height / 2);
	
	$("#modal_ajax_loader").css("top", top);
	$("#modal_ajax_loader").css("left", left);
	$("#modal_ajax_loader").css("display", "inline-block");
	
	return false;
}

function hide_modal_ajax_loader() {
	$("#modal_ajax_loader").hide();
	
	return false;
}

function show_error($target, error) {
	$target.find(".error_msg").html(error);
	$target.show();
}

$(document).ready(function() {
	$("#find_folder_btn").on("click", function() {		
		var $form_target = $(this).closest("form");
		var $error_target = $form_target.find(".error");
		var box_account_id = $("#box_account_id").val();
		var folder_query = $("#folder_query").val();
		var $search_results = $("#search_results");
		var $search_results_table = $search_results.find(".table").first();
		var $search_results_info = $search_results.find(".info").first();
		
		$error_target.hide();
		$search_results_info.hide();
		$search_results_table.hide();

		$search_results.hide();
		
		var error_msg = "";
		
		if (box_account_id == "0") {
			error_msg = "Please select a Box Account.<br>";
		}
		
		if (folder_query == "") {
			error_msg += "Please enter the folder name.";
		}
		
		if (error_msg != "") {
			show_error($error_target, error_msg);
		} else {
			display_modal_overlay();
			display_modal_ajax_loader();
			
			var ajax_error = "Unable to find folder info. Please try again later.";
			var url = baseUri + "ajax/search.php?box_account_id=" + box_account_id + "&folder_query=" + folder_query;

			$.ajax({ 
				type: "GET",
				url: url,
				cache: false,
				dataType: "json",
				success: function(jsonData){
					hide_modal_overlay();
					hide_modal_ajax_loader();

					if (jsonData.length == 0) {
						$search_results_info.html("No folders were found. Try a different account or a different folder name.");
						
						$search_results.show();
						$search_results_info.show();
					} else {
						var html_rows = "";

						for (var i = 0; i < jsonData.length; i++) {
							html_rows += "<tr> \
												<th><div><span class='glyphicon glyphicon-folder-close'></span> <span class='folder_name'>" + jsonData[i]["name"] + "</span></div></th> \
												<td> \
													<button type='button' class='btn btn-success get_share_urls_btn' data-folder-id='" + jsonData[i]["id"] + "'> \
														<span class='glyphicon glyphicon-link'></span> Get Share URLs \
													</button> \
												</td> \
											</tr>";	
						}

						$search_results_table.html(html_rows);
						$search_results_table.show();

						$search_results.show();
					}
				},
				error: function (){
					hide_modal_overlay();
					hide_modal_ajax_loader();
					
					show_error($error_target, ajax_error);
				}
			});
		}
	});

	$("#get_share_urls_btn").on("click", function() {
		var folder_id = $(this).attr("data-folder-id");
		var folder_name = $(this).attr("data-folder-name");
		var $share_urls_modal = $("#share_urls_modal");
		var $share_urls_modal_info = $share_urls_modal.find(".info").first();
		var $share_urls_modal_textarea = $share_urls_modal.find("#share_urls_modal_textarea");
		var $share_urls_modal_copy_btn = $share_urls_modal.find("#share_urls_modal_copy_btn");

		$share_urls_modal_info.hide();
		$share_urls_modal_textarea.hide();
		$share_urls_modal_copy_btn.hide();

		display_modal_overlay();
		display_modal_ajax_loader();
		
		var ajax_error = "Unable to get share URLs. Please try again later.";
		var url = baseUri + "ajax/get-share-urls.php?box_account_id=" + box_account_id + "&folder_id=" + folder_id;

		$.ajax({ 
			type: "GET",
			url: url,
			cache: false,
			dataType: "json",
			success: function(jsonData){
				hide_modal_overlay();
				hide_modal_ajax_loader();

				if (jsonData.length == 0) {
					$share_urls_modal_info.html("There are no items in this folder.");
					
					$share_urls_modal_info.show();
				} else {
					var share_urls = "";
					var share_urls_rows = jsonData.length < 20 ? jsonData.length : 20;

					for (var i = 0; i < jsonData.length; i++) {
						share_urls += jsonData[i]["file_share_url"] + "\n";
					}

					$share_urls_modal_textarea.val(share_urls);
					$share_urls_modal_textarea.attr("rows", share_urls_rows);

					$share_urls_modal_textarea.show();
					$share_urls_modal_copy_btn.show();
				}

				$share_urls_modal.find("strong").html(folder_name);

				$share_urls_modal.modal('show');
			},
			error: function (){
				hide_modal_overlay();
				hide_modal_ajax_loader();
				
				alert(ajax_error);
			}
		});
	});

	$('#folder_tree')
	.on('changed.jstree', function (e, data) {
		$("#get_share_urls_info").hide();
		$("#get_share_urls_btn").show();

		var i, j, r = [];

		for(i = 0, j = data.selected.length; i < j; i++) {
			$("#get_share_urls_btn").attr("data-folder-name", data.instance.get_node(data.selected[i]).text);
			$("#get_share_urls_btn").attr("data-folder-id", data.instance.get_node(data.selected[i]).id);
		}
	})
	.jstree({
		'core' : {
			"themes" : { "stripes" : true },
			'data' : {
				"url" : baseUri + "ajax/get_folder.php?box_account_id=" + box_account_id,
				"data" : function (node) {
					return { "id" : node.id };
				}
			}
		}
	});

	$("#share_urls_modal_copy_btn").on("click", function() {
		var copyText = $("#share_urls_modal_textarea");

		copyText.select();

		document.execCommand("Copy");
	});
});	