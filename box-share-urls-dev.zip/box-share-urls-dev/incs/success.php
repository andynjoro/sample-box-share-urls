<?php
	if (isset($success_msg) && $success_msg != "") {
?>
<div class="alert alert-success success">
	<table width="100%">
		<tr>
			<td width="30" align="left" valign="top">
				<span class="glyphicon glyphicon-ok"></span>
			</td>
			<td width="*" align="left" valign="top">
				<span class="success_msg"><?php echo $success_msg; ?></span>
			</td>
		</tr>
	</table>
</div>
<?php
		$success_msg = "";
	}
?>