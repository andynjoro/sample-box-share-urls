<div class="alert alert-danger error">
	<table width="100%">
		<tr>
			<td width="30" align="left" valign="top">
				<span class="glyphicon glyphicon-warning-sign"></span>
			</td>
			<td width="*" align="left" valign="top">
				<span class="error_msg"></span>
			</td>
		</tr>
	</table>
</div>