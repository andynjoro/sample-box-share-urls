<div id="modal_overlay">&nbsp;</div>
<div id="modal_ajax_loader">
	<div class="progress">
		<div class="progress-bar progress-bar-striped active" role="progressbar" style="width:100%;">
			<span class="h3">Processing...</span>
	  </div>
	</div>
</div>
<script src="js/jquery-1.12.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jstree.min.js"></script>
<script src="js/global.js"></script>
<script type="text/javascript">
<?php
	echo "var baseUri = '" . _SITE_URL_ . "/';";
?>
</script>