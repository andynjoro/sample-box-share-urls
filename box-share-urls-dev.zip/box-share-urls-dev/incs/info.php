<div class="alert alert-info info">
	<table width="100%">
		<tr>
			<td width="30" align="left" valign="top">
				<span class="glyphicon glyphicon-info-sign"></span>
			</td>
			<td width="*" align="left" valign="top">
				<span class="info_msg"></span>
			</td>
		</tr>
	</table>
</div>