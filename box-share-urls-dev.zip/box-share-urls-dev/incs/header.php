<table width="100%" class="space2">
	<tr>
		<td>
			<div class="pull-left">
				<a href="index.php"><h1><img src="img/logo.jpg" id="logo" hspace="5" /> Box Share URLs</h1></a>
			</div>	
		</td>
		<td>
			<div class="dropdown pull-right">
			  <button class="btn btn-default dropdown-toggle" type="button" id="header_dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
				<?php echo $account["name"]; ?>
				<span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu" aria-labelledby="header_dropdown">
				<li><a href="sign_in.php?action=sign_out">Sign Out</a></li>
			  </ul>
			</div>
		</td>
	</tr>
</table>

