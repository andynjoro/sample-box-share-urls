<?php
	if (version_compare(phpversion(), '5.4.0', '<')) {
		if(session_id() == '') {
			session_start();
		}
	} else {
		if (session_status() == PHP_SESSION_NONE) {
			session_start();
		}
	}
	
	//check if account session variable is set
	if (isset($_SESSION["account"])) {
		//get account details
		$account = $_SESSION["account"];
		
		//check if user has token
		if (!isset($account["token"])) {
			//redirect to sign in
			$redirect_url = _AUTH_SITE_URL_ . "/index.php";
			header("location: $redirect_url");
			die();
		}
	} else {
		//redirect to sign in
		$redirect_url = _AUTH_SITE_URL_ . "/index.php";
		header("location: $redirect_url");
		die();
	}
?>