<?php
	include "config/config.php";
	include "incs/check_login.php";

	// Get Box Account
	$box_account_url = "http://localhost:3000/account?email=" . $account["email"];
	$box_account_json = file_get_contents($box_account_url);

	$box_account = json_decode($box_account_json);

	$box_account_id = 0;

	if (count($box_account) > 0) {
		$box_account_id = $box_account[0]->id;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Box Share URLs</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/jstree/style.min.css" rel="stylesheet">
	<link href="css/global.css" rel="stylesheet">
</head>
<body>	
	<div class="container">
		<?php include "incs/header.php"; ?>
		
		<?php if ($box_account_id == 0) { ?>

		<div class="alert alert-info info" style="display: block;">
			<table width="100%">
				<tr>
					<td width="30" align="left" valign="top">
						<span class="glyphicon glyphicon-info-sign"></span>
					</td>
					<td width="*" align="left" valign="top">
						<span class="info_msg">Sorry, there is no Box account associated with your account. Please contact the System Administrator to have one set up for you.</span>
					</td>
				</tr>
			</table>
		</div>

		<?php } else { ?>

		
		
		<table width="100%">
			<tr>
				<td align="left" valign="middle">
					<h2>Box Folders</h2>
				</td>
				<td align="right" valign="middle">
					<div id="get_share_urls_info" class="label label-default">Click on a folder to generate share URLs</div>
					<button id="get_share_urls_btn" class="btn btn-primary">Generate Share URLs</button>
				</td>
			</tr>
		</table>
		
		<div class="space2"></div>

		<?php include "incs/info.php"; ?>

		<div id="folder_tree"></div>
		
		<div class="modal fade" tabindex="-1" role="dialog" id="share_urls_modal">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title">Share URLs for folder <strong></strong> </h4>
					</div>
					<div class="modal-body">
						<?php include "incs/info.php"; ?>
						
						<textarea id="share_urls_modal_textarea" class="form-control space2"></textarea>

						<button id="share_urls_modal_copy_btn" class="btn btn-lg btn-primary">Copy Share URLs</button>

					</div>
				</div>
			</div>
		</div>
		
		<script>
			var box_account_id = <?php echo $box_account_id; ?>
		</script>

		<?php }  ?>
	</div>	
	<?php include "incs/footer.php"; ?>
</body>
</html>