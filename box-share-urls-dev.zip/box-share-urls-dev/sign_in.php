<?php include "config/config.php"; ?>
<?php
	if (version_compare(phpversion(), '5.4.0', '<')) {
		if(session_id() == '') {
			session_start();
		}
	} else {
		if (session_status() == PHP_SESSION_NONE) {
			session_start();
		}
	}
	
	//check if user wants to sign out	
	if (isset($_GET['action'])) {
		$action = $_GET['action'];
		
		if ($action == "sign_out") {
			unset($_SESSION["account"]);
			
			//redirect to authentication site
			$redirect_url = _AUTH_SITE_URL_ . "/index.php";
			header("location: $redirect_url");
			die();
		}
	}
	
	//check if user wants to login with a token
	if (isset($_GET["t"]) && isset($_GET["e"])) {
		$email = urldecode(trim($_GET["e"]));
		$name = urldecode(trim($_GET["n"]));
		$token = urldecode(trim($_GET["t"]));
		
		//register the account details in session
		$account = array();
		$account["email"] = $email;
		$account["name"] = $name;
		$account["token"] = $token;
		
		$_SESSION['account'] = $account;
		session_write_close();
		
		//redirect to index
		$redirect_url = _SITE_URL_ . "/index.php";
		header("location: $redirect_url");
		die();
	} else {
		//redirect to authentication site
		$redirect_url = _AUTH_SITE_URL_ . "/index.php";
		header("location: $redirect_url");
		die();
	}
?>