<div class="modal" tabindex="-1" role="dialog" id="processing_modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Processing...</h5>
            </div>
            <div class="modal-body">
                <div class="text-center">
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                    <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Travis Wood\Site\resources\views/includes/processing_modal.blade.php ENDPATH**/ ?>