<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-4">
        <div class="col-4">
            <h2>Add Customer</h2>
        </div>
        <div class="col-4">
            
        </div>
        <div class="col-4 text-right">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-link">&lsaquo; Back to Customers</a>
        </div>
    </div>

    <div class="mt-4 bg-white p-4">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="col-4">
            <form class="needs-validation" novalidate method="post" action="<?php echo e(url('/customer/store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Customer Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo e(old('name')); ?>" required>
                    <div class="invalid-feedback">Please enter the customer's name.</div>
                </div>
                <div class="form-group">
                    <label for="email_address">Email address</label>
                    <input type="email" class="form-control" id="email_address" name="email_address" placeholder="Enter Email Address" value="<?php echo e(old('email_address')); ?>" required>
                    <div class="invalid-feedback">Please enter a valid email address.</div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>    
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nourishing Brands\Site\resources\views/customer_create.blade.php ENDPATH**/ ?>