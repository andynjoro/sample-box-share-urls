<?php if(count($customers) === 0): ?>
    <div class="alert alert-info" role="alert">
        No customers were found.
    </div>
<?php else: ?>
    <table class="table table-striped mt-4">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email Address</th>
                <th scope="col">Charge Customer</th>
                <th scope="col">Connect Bank Account</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($customer->id); ?></th>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->email_address); ?></td>
                <td>
                    <?php if($customer->stripe_bank_id == null): ?>
                        <button type="button" class="btn btn-secondary" disabled>Charge Customer</button>
                    <?php else: ?>
                        <a href="<?php echo e(url('ach/charge')); ?>/<?php echo e($customer->hash); ?>" class="btn btn-primary">Charge Customer</a>
                    <?php endif; ?>
                </td>
                <td>
                    <a target="_blank" href="<?php echo e(url('/ach')); ?>/<?php echo e($customer->hash); ?>" class="btn btn-primary">Connect</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH D:\Nourishing Brands\Site\resources\views/includes/customer_list.blade.php ENDPATH**/ ?>