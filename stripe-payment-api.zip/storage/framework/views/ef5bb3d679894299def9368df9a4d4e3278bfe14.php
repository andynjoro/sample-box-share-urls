 
<?php $__env->startSection('content'); ?>
<div class="container">
  <h2 class="mt-4"><?php echo e($customer->name); ?></h2>
  <h4 class="mt-3 mb-4">We just need to verify that it's really you</h4>

  <?php if(session('code_sent')): ?>
    <div class="alert alert-info" role="alert">
        <div>A two factor authentication code has been sent to your email address <?php echo e(substr($customer->email_address, 0, 3)); ?>******<?php echo e(substr($customer->email_address, 9)); ?>.</div>
    </div>
  <?php endif; ?>
  <div class="row justify-content-left">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header h5">Enter Two Factor Authentication Token</div>
        <div class="card-body">
            <?php if(session('wrong_code')): ?>
                <div class="alert alert-danger" role="alert">
                    <div class="mb-2">You have entered an incorrect code or your code has expired.</div>
                    <div>
                        <form action='<?php echo e(url("/ach/$hash/2fa/resend")); ?>' method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary btn-large">Resend Code?</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <form action='<?php echo e(url("/ach/$hash/2fa/verify")); ?>' method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="token">Token</label>
                <input type="text" name="token" placeholder="Enter received token" class="form-control<?php echo e($errors->has('token') ? ' is-invalid' : ''); ?>"
                    id="token"> <?php if($errors->has('token')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('token')); ?></strong>
                    </span> <?php endif; ?>
                </div>

                <button class="btn btn-primary btn-large">Verify</button>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Travis Wood\Site\resources\views/two_factor_auth.blade.php ENDPATH**/ ?>