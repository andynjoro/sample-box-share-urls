<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4"><?php echo e($customer->name); ?></h2>

    <div class="col-12 col-lg-6 mt-4 bg-white p-4">
        <?php if(isset($bank_account)): ?>
            <?php echo $__env->make('includes.bank_account_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('includes.add_bank_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('includes.processing_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Travis Wood\Site\resources\views/ach.blade.php ENDPATH**/ ?>