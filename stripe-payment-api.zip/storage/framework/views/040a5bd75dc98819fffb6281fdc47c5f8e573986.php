<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-4">
        <div class="col-8">
            <h2><?php echo e($customer->name); ?></h2>
        </div>
        
        <div class="col-4 text-right">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-link">&lsaquo; Back to All Customers</a>
        </div>
    </div>

    <div class="mt-4 bg-white p-4">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="col-6">
            <h3 class="mb-3">Add Bank Account Details</h3>
            <form class="needs-validation" novalidate method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="account_holder_name">Account Holder's Name</label>
                    <input type="text" value="<?php echo e(old('account_holder_name')); ?>" class="form-control" id="account_holder_name" placeholder="Enter name" name="account_holder_name" required>
                    <div class="invalid-feedback">Please enter the account holder's name.</div>
                </div>
                <div class="form-group">
                    <label for="account_holder_type">Account Type</label>
                    <select name="account_holder_type" class="custom-select">
                        <option value="company">Company</option>
                        <option value="individual">Individual</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="routing_number">Routing Number</label>
                    <input type="text" value="<?php echo e(old('routing_number')); ?>" class="form-control" id="routing_number" placeholder="Enter routing number" name="routing_number" required>
                    <div class="invalid-feedback">Please enter the routing number.</div>
                </div>
                <div class="form-group">
                    <label for="account_number">Account Number</label>
                    <input type="text" value="<?php echo e(old('account_number')); ?>" class="form-control" id="account_number" placeholder="Enter account number" name="account_number" required>
                    <div class="invalid-feedback">Please enter the account number.</div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nourishing Brands\Site\resources\views/ach_bank_account_add.blade.php ENDPATH**/ ?>