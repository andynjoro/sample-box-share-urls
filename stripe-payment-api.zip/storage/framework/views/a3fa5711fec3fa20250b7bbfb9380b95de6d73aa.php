<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Verification Code</title>
</head>

<body>
    <h1 style="font-family: Helvetica, Arial, sans-serif;">Your Two Factor Authentication Code</h1>
    <h2 style="font-family: Helvetica, Arial, sans-serif;"><?php echo e($token); ?></h2>
    <p style="font-family: Helvetica, Arial, sans-serif;">Thanks,<br>Travis Wood LLC.</p>
</body>

</html><?php /**PATH D:\Travis Wood\Site\resources\views/email/2fa.blade.php ENDPATH**/ ?>