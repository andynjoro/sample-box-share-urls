<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-4">
        <div class="col-8">
            <h2>Charge Result for <?php echo e($customer->name); ?></h2>
        </div>
        <div class="col-4 text-right">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-link">&lsaquo; Back to All Customers</a>
        </div>
    </div>

    <div class="mt-4 bg-white p-4">
        <div class="bg-light p-4">
            <h4><?php echo e($bank_account->bank_name); ?></h4>
            <h5><?php echo e($bank_account->account_holder_name); ?></h5>
            <h6>Account ending in <?php echo e($bank_account->last4); ?></h6>
        </div>

        <?php if($stripe_charge->status == "succeeded"): ?>
            <div class="alert alert-success mt-4" role="alert">
                <h5>Transaction processed successfully</h5>
                <div class="mb-2">Amount: <strong>USD <?php echo e($stripe_charge->amount/100); ?></strong></div>
                <div>Description: <strong><?php echo e($stripe_charge->description); ?></strong></div>
            </div>
        <?php elseif($stripe_charge->status == "pending"): ?>
            <div class="alert alert-warning mt-4" role="alert">
                <h5>Transaction pending</h5>
                <div class="mb-2">Amount: <strong>USD <?php echo e($stripe_charge->amount/100); ?></strong></div>
                <div>Description: <strong><?php echo e($stripe_charge->description); ?></strong></div>
            </div>
        <?php elseif($stripe_charge->status == "failed"): ?>
            <div class="alert alert-danger mt-4" role="alert">
                <h5>Transaction failed</h5>
                <div class="mb-2">Amount: <strong>USD <?php echo e($stripe_charge->amount/100); ?></strong></div>
                <div>Description: <strong><?php echo e($stripe_charge->description); ?></strong></div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nourishing Brands\Site\resources\views/customer_charge_result.blade.php ENDPATH**/ ?>