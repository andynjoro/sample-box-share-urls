<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4"><?php echo e($customer->name); ?></h2>

    <div class="mt-4 bg-white p-4">
        <?php if($customer->stripe_bank_id != null): ?>
            <div class="col-6">
                <h3 class="mb-3">Your Bank Account Details</h3>
                <div class="bg-light p-4">
                    <h4><?php echo e($bank_account->bank_name); ?></h4>
                    <h5><?php echo e($bank_account->account_holder_name); ?></h5>
                    <h6>Account ending in <?php echo e($bank_account->last4); ?></h6>
                    <h4>
                        <?php if($bank_account->status == "verified"): ?>
                            <span class="badge badge-success"><?php echo e(ucfirst($bank_account->status)); ?></span>
                        <?php else: ?>
                        <span class="badge badge-secondary"><?php echo e(ucfirst($bank_account->status)); ?></span>
                        <?php endif; ?>
                    </h4>
                </div>
            </div>
        <?php else: ?>
        <div class="modal" tabindex="-1" role="dialog" id="processing_modal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Processing your account...</h5>
                    </div>
                    <div class="modal-body">
                        <div class="text-center">
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                            <span class="spinner-grow text-info" role="status" aria-hidden="true"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <h3 class="mb-3">Connect your bank account</h3>
            
            <div id="plaid_errors" class="alert alert-danger d-none"></div>

            <div class="mt-4">
                <button id="linkButton" class="btn btn-lg btn-primary shadow">
                    <img src="<?php echo e(asset('img/plaid_logo.png')); ?>" width="28" class="align-bottom" />
                    <span class="ml-1">Connect via Plaid</span>
                </button>

                <a href="#" class="btn btn-lg btn-primary shadow ml-2">Manually Add Bank Account</a>
            </div>
        </div>
        
        <script src="https://cdn.plaid.com/link/v2/stable/link-initialize.js"></script>
        <script>    
            var user_error = "Something went wrong while trying to link your bank account. Please try again later.";

            var linkHandler = Plaid.create({
                env: '<?php echo e(env('PLAID_ENV')); ?>',
                clientName: 'Travis Wood',
                key: '<?php echo e(env('PLAID_KEY')); ?>',
                product: ['auth'],
                selectAccount: true,
                onSuccess: function(public_token, metadata) {
                    $('#processing_modal').modal('show');

                    // Send the public_token and account ID to your app server.
                    var data = {
                        hash: "<?php echo e($hash); ?>",
                        public_token: public_token,
                        account_id: metadata.account_id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    };

                    $.ajax({
                        method: "POST",
                        url: "<?php echo e(url('/customer/ach/processPlaid')); ?>",
                        data: data
                    }).always(function() {
                        $('#processing_modal').modal('hide');
                    }).done(function(response) {
                        if (response.status == 'success') {
                            window.location.href = window.location.href;
                        } else {
                            $("#plaid_errors").html(user_error).removeClass("d-none");;
                        }
                    }).fail(function() {
                        $("#plaid_errors").html(user_error).removeClass("d-none");
                    });
                },
                onExit: function(err, metadata) {
                    // The user exited the Link flow.
                    if (err != null) {
                        // The user encountered a Plaid API error prior to exiting.
                        $("#plaid_errors").html(user_error).removeClass("d-none");;
                    }
                },
            });

            // Trigger the Link UI
            document.getElementById('linkButton').onclick = function() {
                linkHandler.open();
            };
        </script>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Nourishing Brands\Site\resources\views/customer_ach.blade.php ENDPATH**/ ?>